export class ApiResponse {

  token: any;
  user_display_name: any;
  user_email: any;
}
