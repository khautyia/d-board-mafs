export class MarketPrice {

    entry: any = [];
  
  }
  